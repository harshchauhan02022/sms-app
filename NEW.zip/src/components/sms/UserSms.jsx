import React from 'react'

const UserSms = () => {
  return (
    <div>UserSms</div>
  )
}

export default UserSms