export const Notfound = () => {
    return <div className="notfound">
        Not Found
    </div>
}